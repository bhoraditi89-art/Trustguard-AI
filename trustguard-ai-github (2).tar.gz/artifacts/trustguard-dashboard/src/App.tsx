import { useMemo, useRef, useState, type FormEvent, type ReactNode, type RefObject } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  Activity,
  AlertTriangle,
  ArrowUpRight,
  BarChart3,
  Bell,
  Check,
  ChevronRight,
  CircleHelp,
  ClipboardPaste,
  Eye,
  Globe2,
  LayoutDashboard,
  LockKeyhole,
  Menu,
  Radar,
  RefreshCw,
  ScanLine,
  Search,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  X,
} from 'lucide-react';
import { useAnalyzeContent, useHealthCheck } from '@workspace/api-client-react';
import type { FlaggedItem } from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();

type LocalScan = {
  id: string;
  label: string;
  detail: string;
  flags: number;
  score: number;
  time: string;
  content: string;
};

const initialScans: LocalScan[] = [
  {
    id: 'scan-01',
    label: 'checkout / plan selection',
    detail: 'pricing.example.test',
    flags: 3,
    score: 72,
    time: '8 min ago',
    content: 'Only 2 spots left — upgrade now before this offer disappears.',
  },
  {
    id: 'scan-02',
    label: 'newsletter / consent gate',
    detail: 'dailybrief.example.test',
    flags: 2,
    score: 44,
    time: '1 hr ago',
    content: 'No thanks, I prefer to miss out on the best stories.',
  },
  {
    id: 'scan-03',
    label: 'account / trial offer',
    detail: 'workspace.example.test',
    flags: 1,
    score: 38,
    time: 'Yesterday',
    content: 'Start your free trial today. Cancel any time in your settings.',
  },
];

const categoryMeta: Record<string, { label: string; color: string; short: string }> = {
  'False Urgency': { label: 'False urgency', color: 'bg-[hsl(var(--accent))]', short: 'Urgency' },
  'Hidden Cost': { label: 'Hidden cost', color: 'bg-[#4e8d9a]', short: 'Cost' },
  Confirmshaming: { label: 'Confirmshaming', color: 'bg-[#dfbc58]', short: 'Shaming' },
};

const sampleCopy =
  'Only 2 spots left — upgrade now before this offer disappears.\nNo thanks, I prefer to miss out on the best stories.';

function scoreTone(score: number) {
  if (score >= 70) return 'text-[hsl(var(--destructive))] bg-[hsl(var(--destructive)/.1)]';
  if (score >= 40) return 'text-[#a67c19] bg-[#f6e9be]';
  return 'text-[#35727e] bg-[#dcecef]';
}

function scoreLabel(score: number) {
  if (score >= 70) return 'High signal';
  if (score >= 40) return 'Review';
  return 'Low signal';
}

function Sidebar({
  mobileOpen,
  onClose,
}: {
  mobileOpen: boolean;
  onClose: () => void;
}) {
  const [active, setActive] = useState('Command center');
  const navItems = [
    { label: 'Command center', icon: LayoutDashboard },
    { label: 'Scan content', icon: ScanLine, count: 'NEW' },
    { label: 'Domain watch', icon: Globe2 },
    { label: 'Pattern library', icon: Radar },
  ];

  return (
    <>
      {mobileOpen && (
        <button
          type="button"
          data-testid="button-close-sidebar-overlay"
          aria-label="Close navigation"
          onClick={onClose}
          className="fixed inset-0 z-30 bg-[#12282d]/45 lg:hidden"
        />
      )}
      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-[258px] flex-col border-r border-[hsl(var(--sidebar-border))] bg-[hsl(var(--sidebar))] px-5 py-6 text-[hsl(var(--sidebar-foreground))] transition-transform duration-300 lg:translate-x-0 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-[11px] bg-[hsl(var(--sidebar-primary))] text-[hsl(var(--sidebar-primary-foreground))]">
              <ShieldCheck size={20} strokeWidth={2.3} />
            </div>
            <div>
              <p className="text-[15px] font-extrabold tracking-[-0.04em]">trustguard</p>
              <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-[hsl(var(--sidebar-foreground)/.48)]">
                clarity layer
              </p>
            </div>
          </div>
          <button
            type="button"
            data-testid="button-close-sidebar"
            aria-label="Close navigation"
            onClick={onClose}
            className="focus-ring rounded-lg p-1.5 text-[hsl(var(--sidebar-foreground)/.6)] hover:bg-[hsl(var(--sidebar-accent))] lg:hidden"
          >
            <X size={18} />
          </button>
        </div>

        <div className="mt-12">
          <p className="mb-3 px-3 font-mono text-[9px] uppercase tracking-[0.2em] text-[hsl(var(--sidebar-foreground)/.38)]">
            Workspace
          </p>
          <nav className="space-y-1" aria-label="Main navigation">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = active === item.label;
              return (
                <button
                  type="button"
                  key={item.label}
                  data-testid={`button-nav-${item.label.toLowerCase().replaceAll(' ', '-')}`}
                  onClick={() => {
                    setActive(item.label);
                    onClose();
                  }}
                  className={`focus-ring group flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-[12px] font-semibold transition-colors ${
                    isActive
                      ? 'bg-[hsl(var(--sidebar-accent))] text-[hsl(var(--sidebar-foreground))]'
                      : 'text-[hsl(var(--sidebar-foreground)/.58)] hover:bg-[hsl(var(--sidebar-accent)/.62)] hover:text-[hsl(var(--sidebar-foreground))]'
                  }`}
                >
                  <Icon size={17} strokeWidth={isActive ? 2.2 : 1.8} />
                  <span className="flex-1">{item.label}</span>
                  {item.count && (
                    <span className="rounded bg-[hsl(var(--sidebar-primary)/.15)] px-1.5 py-0.5 font-mono text-[8px] tracking-[0.1em] text-[hsl(var(--sidebar-primary))]">
                      {item.count}
                    </span>
                  )}
                  {isActive && <span className="h-1.5 w-1.5 rounded-full bg-[hsl(var(--sidebar-primary))]" />}
                </button>
              );
            })}
          </nav>
        </div>

        <div className="mt-auto">
          <div className="mb-6 rounded-2xl border border-[hsl(var(--sidebar-border))] bg-[hsl(var(--sidebar-accent)/.52)] p-4">
            <div className="mb-3 flex items-center gap-2">
              <LockKeyhole size={14} className="text-[hsl(var(--sidebar-primary))]" />
              <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-[hsl(var(--sidebar-foreground)/.58)]">
                Private by default
              </span>
            </div>
            <p className="text-[11px] leading-[1.6] text-[hsl(var(--sidebar-foreground)/.72)]">
              Content stays in your session. TrustGuard only returns the signals you need.
            </p>
          </div>
          <button
            type="button"
            data-testid="button-open-help"
            onClick={() => window.alert('TrustGuard reads language patterns, not your identity.')}
            className="focus-ring flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-[11px] font-semibold text-[hsl(var(--sidebar-foreground)/.53)] hover:bg-[hsl(var(--sidebar-accent)/.62)] hover:text-[hsl(var(--sidebar-foreground))]"
          >
            <CircleHelp size={16} />
            How TrustGuard works
            <ArrowUpRight size={13} className="ml-auto" />
          </button>
          <p className="mt-7 px-3 font-mono text-[9px] uppercase tracking-[0.12em] text-[hsl(var(--sidebar-foreground)/.3)]">
            v0.8.4 / local session
          </p>
        </div>
      </aside>
    </>
  );
}

function Metric({
  label,
  value,
  detail,
  icon: Icon,
  accent = 'lime',
}: {
  label: string;
  value: string;
  detail: string;
  icon: typeof Activity;
  accent?: 'lime' | 'coral' | 'teal';
}) {
  const accents = {
    lime: 'text-[hsl(var(--primary))] bg-[hsl(var(--primary)/.14)]',
    coral: 'text-[hsl(var(--accent))] bg-[hsl(var(--accent)/.13)]',
    teal: 'text-[#4e8d9a] bg-[#dcecef]',
  };
  return (
    <div className="reveal-up rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-4 shadow-[var(--shadow-sm)] sm:p-5">
      <div className="flex items-start justify-between">
        <p className="font-mono text-[9px] uppercase tracking-[0.16em] text-[hsl(var(--muted-foreground))]">{label}</p>
        <div className={`rounded-lg p-2 ${accents[accent]}`}>
          <Icon size={15} />
        </div>
      </div>
      <p data-testid={`metric-${label.toLowerCase().replaceAll(' ', '-')}`} className="mt-4 text-[28px] font-extrabold tracking-[-0.07em] text-[hsl(var(--foreground))]">
        {value}
      </p>
      <p className="mt-1 text-[10px] text-[hsl(var(--muted-foreground))]">{detail}</p>
    </div>
  );
}

function Analyzer({
  draft,
  setDraft,
  results,
  isPending,
  error,
  onAnalyze,
  onExample,
  analyzerRef,
}: {
  draft: string;
  setDraft: (value: string) => void;
  results: FlaggedItem[];
  isPending: boolean;
  error: string;
  onAnalyze: (event: FormEvent<HTMLFormElement>) => void;
  onExample: () => void;
  analyzerRef: RefObject<HTMLElement | null>;
}) {
  return (
    <section ref={analyzerRef} className="reveal-up delay-2 rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] shadow-[var(--shadow-sm)]">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[hsl(var(--border))] px-5 py-5 sm:px-6">
        <div>
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-[hsl(var(--primary))]" />
            <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-[hsl(var(--muted-foreground))]">Live analyzer</p>
          </div>
          <h2 className="mt-2 text-[18px] font-extrabold tracking-[-0.05em]">What is this page asking of me?</h2>
        </div>
        <span className="rounded-full border border-[hsl(var(--border))] px-3 py-1 font-mono text-[9px] uppercase tracking-[0.12em] text-[hsl(var(--muted-foreground))]">
          1 — 500 snippets
        </span>
      </div>
      <form onSubmit={onAnalyze} className="p-5 sm:p-6">
        <label htmlFor="content-to-analyze" className="mb-2 block text-[11px] font-semibold text-[hsl(var(--foreground)/.76)]">
          Paste text from a page, pop-up, or checkout flow
        </label>
        <div className="relative">
          <textarea
            id="content-to-analyze"
            data-testid="input-content-to-analyze"
            value={draft}
            onChange={(event) => setDraft(event.target.value)}
            placeholder="Paste the words that made you pause…"
            className="focus-ring min-h-[142px] w-full resize-y rounded-xl border border-[hsl(var(--input))] bg-[hsl(var(--background)/.55)] p-4 text-[13px] leading-[1.7] text-[hsl(var(--foreground))] placeholder:text-[hsl(var(--muted-foreground)/.7)] focus:border-[hsl(var(--primary))] focus:outline-none"
            maxLength={10000}
          />
          <span className="absolute bottom-3 right-3 font-mono text-[9px] text-[hsl(var(--muted-foreground)/.65)]">
            {draft.length.toLocaleString()} chars
          </span>
        </div>
        <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              type="button"
              data-testid="button-use-example"
              onClick={onExample}
              className="focus-ring flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-[10px] font-semibold text-[hsl(var(--muted-foreground))] hover:bg-[hsl(var(--muted))] hover:text-[hsl(var(--foreground))]"
            >
              <Sparkles size={13} />
              Try an example
            </button>
            <span className="hidden text-[10px] text-[hsl(var(--muted-foreground)/.7)] sm:inline">Separate snippets with a new line</span>
          </div>
          <button
            type="submit"
            data-testid="button-analyze-content"
            disabled={isPending || !draft.trim()}
            className="focus-ring flex items-center gap-2 rounded-xl bg-[hsl(var(--secondary))] px-4 py-2.5 text-[11px] font-bold text-[hsl(var(--secondary-foreground))] transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-45 disabled:hover:translate-y-0"
          >
            {isPending ? (
              <>
                <ScanLine size={14} />
                Reading signals
              </>
            ) : (
              <>
                Analyze content
                <ArrowUpRight size={14} />
              </>
            )}
          </button>
        </div>
        {isPending && (
          <div className="mt-4">
            <div className="relative h-1 overflow-hidden rounded-full bg-[hsl(var(--muted))] scan-progress" />
            <p data-testid="status-analysis-loading" className="mt-2 font-mono text-[9px] uppercase tracking-[0.12em] text-[hsl(var(--muted-foreground))]">
              Comparing language against known manipulation patterns
            </p>
          </div>
        )}
        {error && (
          <div data-testid="status-analysis-error" className="mt-4 flex items-start gap-2 rounded-xl border border-[hsl(var(--destructive)/.22)] bg-[hsl(var(--destructive)/.07)] p-3 text-[11px] text-[hsl(var(--destructive))]">
            <AlertTriangle size={15} className="mt-0.5 shrink-0" />
            <span>{error}</span>
          </div>
        )}
      </form>

      <div className="border-t border-[hsl(var(--border))]">
        {results.length > 0 ? (
          <div className="divide-y divide-[hsl(var(--border))]">
            <div className="flex items-center justify-between px-5 py-4 sm:px-6">
              <p className="font-mono text-[9px] uppercase tracking-[0.17em] text-[hsl(var(--muted-foreground))]">
                Scan result / {results.length} signals
              </p>
              <span data-testid="status-scan-complete" className="flex items-center gap-1.5 text-[10px] font-bold text-[#35727e]">
                <Check size={13} /> Complete
              </span>
            </div>
            {results.map((item, index) => {
              const meta = categoryMeta[item.category] ?? { label: item.category, color: 'bg-[#4e8d9a]', short: 'Signal' };
              return (
                <div data-testid={`row-flagged-item-${index}`} key={`${item.text}-${index}`} className="px-5 py-4 sm:px-6">
                  <div className="flex items-start justify-between gap-4">
                    <div className="min-w-0">
                      <div className="mb-2 flex flex-wrap items-center gap-2">
                        <span className={`h-1.5 w-1.5 rounded-full ${meta.color}`} />
                        <span className="font-mono text-[9px] uppercase tracking-[0.13em] text-[hsl(var(--muted-foreground))]">{meta.label}</span>
                        <span className="text-[9px] text-[hsl(var(--muted-foreground)/.55)]">•</span>
                        <span className="font-mono text-[9px] text-[hsl(var(--muted-foreground)/.75)]">{item.signals.length} signals</span>
                      </div>
                      <p className="text-[12px] font-semibold leading-[1.55]">“{item.text}”</p>
                      <p className="mt-1.5 text-[11px] leading-[1.55] text-[hsl(var(--muted-foreground))]">{item.reason}</p>
                    </div>
                    <div className="shrink-0 text-right">
                      <span className={`inline-flex rounded-full px-2 py-1 font-mono text-[10px] font-medium ${scoreTone(item.threatScore)}`}>
                        {item.threatScore}
                      </span>
                      <p className="mt-1 font-mono text-[8px] uppercase tracking-[0.12em] text-[hsl(var(--muted-foreground)/.7)]">{scoreLabel(item.threatScore)}</p>
                    </div>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {item.signals.map((signal) => (
                      <span key={signal} className="rounded-md bg-[hsl(var(--muted)/.72)] px-2 py-1 text-[9px] text-[hsl(var(--muted-foreground))]">
                        {signal}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="flex items-start gap-3 px-5 py-5 sm:px-6">
            <div className="mt-0.5 rounded-lg bg-[hsl(var(--primary)/.16)] p-2 text-[#62821c]">
              <ClipboardPaste size={15} />
            </div>
            <div>
              <p className="text-[11px] font-bold">Your readout will land here</p>
              <p className="mt-1 text-[10px] leading-[1.5] text-[hsl(var(--muted-foreground))]">
                TrustGuard looks for pressure, missing context, and language that makes opting out feel bad.
              </p>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

function PatternDistribution({ results }: { results: FlaggedItem[] }) {
  const distribution = useMemo(() => {
    const defaults = [
      { label: 'False urgency', value: 42, count: 8, color: 'bg-[hsl(var(--accent))]' },
      { label: 'Hidden cost', value: 31, count: 6, color: 'bg-[#4e8d9a]' },
      { label: 'Confirmshaming', value: 18, count: 4, color: 'bg-[#dfbc58]' },
    ];
    if (!results.length) return defaults;
    const counts = results.reduce<Record<string, number>>((acc, item) => {
      acc[item.category] = (acc[item.category] ?? 0) + 1;
      return acc;
    }, {});
    const total = results.length;
    return [
      { label: 'False urgency', value: Math.round(((counts['False Urgency'] ?? 0) / total) * 100), count: counts['False Urgency'] ?? 0, color: 'bg-[hsl(var(--accent))]' },
      { label: 'Hidden cost', value: Math.round(((counts['Hidden Cost'] ?? 0) / total) * 100), count: counts['Hidden Cost'] ?? 0, color: 'bg-[#4e8d9a]' },
      { label: 'Confirmshaming', value: Math.round(((counts.Confirmshaming ?? 0) / total) * 100), count: counts.Confirmshaming ?? 0, color: 'bg-[#dfbc58]' },
    ];
  }, [results]);

  return (
    <section className="reveal-up delay-3 rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5 shadow-[var(--shadow-sm)] sm:p-6">
      <div className="flex items-start justify-between">
        <div>
          <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-[hsl(var(--muted-foreground))]">Pattern distribution</p>
          <h2 className="mt-2 text-[18px] font-extrabold tracking-[-0.05em]">What keeps showing up</h2>
        </div>
        <BarChart3 size={18} className="text-[hsl(var(--muted-foreground)/.65)]" />
      </div>
      <p className="mt-3 max-w-[290px] text-[11px] leading-[1.55] text-[hsl(var(--muted-foreground))]">
        {results.length ? 'Breakdown from the current scan.' : 'A baseline from your recent local scan log.'}
      </p>
      <div className="mt-8 space-y-5">
        {distribution.map((item) => (
          <div key={item.label}>
            <div className="mb-2 flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <span className={`h-2 w-2 rounded-full ${item.color}`} />
                <span className="text-[11px] font-semibold">{item.label}</span>
              </div>
              <span className="font-mono text-[10px] text-[hsl(var(--muted-foreground))]">{item.count} hits</span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-[hsl(var(--muted))]">
              <div
                className={`h-full rounded-full ${item.color} transition-[width] duration-700`}
                style={{ width: `${Math.max(item.value, item.count ? 5 : 2)}%` }}
              />
            </div>
          </div>
        ))}
      </div>
      <div className="mt-8 border-t border-[hsl(var(--border))] pt-4">
        <div className="flex items-center gap-2 text-[10px] text-[hsl(var(--muted-foreground))]">
          <Eye size={14} />
          <span>One page can carry more than one pattern.</span>
        </div>
      </div>
    </section>
  );
}

function RecentScans({
  scans,
  onReopen,
  showAll,
  onToggleShowAll,
}: {
  scans: LocalScan[];
  onReopen: (content: string) => void;
  showAll: boolean;
  onToggleShowAll: () => void;
}) {
  const visibleScans = showAll ? scans : scans.slice(0, 3);
  return (
    <section className="reveal-up delay-4 rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] shadow-[var(--shadow-sm)]">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[hsl(var(--border))] px-5 py-5 sm:px-6">
        <div>
          <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-[hsl(var(--muted-foreground))]">Recent scans</p>
          <h2 className="mt-2 text-[18px] font-extrabold tracking-[-0.05em]">Your signal trail</h2>
        </div>
        <span className="rounded-full bg-[hsl(var(--primary)/.14)] px-2.5 py-1 font-mono text-[9px] uppercase tracking-[0.12em] text-[#62821c]">Local session</span>
      </div>
      <div className="hidden grid-cols-[1.5fr_1fr_.5fr_.55fr_auto] gap-4 px-6 py-3 font-mono text-[9px] uppercase tracking-[0.14em] text-[hsl(var(--muted-foreground)/.7)] md:grid">
        <span>Surface</span><span>Source</span><span>Flags</span><span>Risk</span><span />
      </div>
      <div className="divide-y divide-[hsl(var(--border))]">
        {visibleScans.map((scan) => (
          <button
            type="button"
            key={scan.id}
            data-testid={`button-reopen-scan-${scan.id}`}
            onClick={() => onReopen(scan.content)}
            className="focus-ring group grid w-full gap-3 px-5 py-4 text-left transition-colors hover:bg-[hsl(var(--background)/.55)] md:grid-cols-[1.5fr_1fr_.5fr_.55fr_auto] md:items-center md:gap-4 md:px-6"
          >
            <span className="min-w-0">
              <span className="block truncate text-[11px] font-bold">{scan.label}</span>
              <span className="mt-1 flex items-center gap-1.5 text-[10px] text-[hsl(var(--muted-foreground))] md:hidden">
                <Globe2 size={11} /> {scan.detail}
              </span>
            </span>
            <span className="hidden items-center gap-1.5 truncate text-[10px] text-[hsl(var(--muted-foreground))] md:flex">
              <Globe2 size={11} /> {scan.detail}
            </span>
            <span className="flex items-center gap-1.5 text-[10px] text-[hsl(var(--muted-foreground))]">
              <AlertTriangle size={12} className={scan.flags > 2 ? 'text-[hsl(var(--accent))]' : 'text-[#a67c19]'} />
              {scan.flags}
            </span>
            <span className="flex items-center gap-2">
              <span className={`rounded-full px-2 py-1 font-mono text-[10px] ${scoreTone(scan.score)}`}>{scan.score}</span>
              <span className="text-[9px] text-[hsl(var(--muted-foreground))] md:hidden">{scan.time}</span>
            </span>
            <ChevronRight size={15} className="ml-auto text-[hsl(var(--muted-foreground)/.5)] transition-transform group-hover:translate-x-0.5" />
          </button>
        ))}
      </div>
      <div className="border-t border-[hsl(var(--border))] px-5 py-4 sm:px-6">
        <button
          type="button"
          data-testid="button-toggle-scan-log"
          onClick={onToggleShowAll}
          className="focus-ring flex items-center gap-1.5 text-[10px] font-bold text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))]"
        >
          {showAll ? 'Show recent only' : `View full scan log (${scans.length})`}
          <ArrowUpRight size={13} />
        </button>
      </div>
    </section>
  );
}

function DomainWatch() {
  const [domains, setDomains] = useState(['quick-prize.net', 'secure-checkout.co']);
  const [draft, setDraft] = useState('');
  const [message, setMessage] = useState('');

  const addDomain = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const clean = draft.trim().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
    if (!clean || domains.includes(clean)) {
      setMessage(clean ? 'Already in your watch list.' : 'Enter a domain to watch.');
      return;
    }
    setDomains((current) => [clean, ...current]);
    setDraft('');
    setMessage('Added to this browser session.');
  };

  return (
    <section className="reveal-up delay-4 rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-5 shadow-[var(--shadow-sm)] sm:p-6">
      <div className="flex items-start justify-between">
        <div>
          <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-[hsl(var(--muted-foreground))]">Top deceptive domains</p>
          <h2 className="mt-2 text-[18px] font-extrabold tracking-[-0.05em]">Where risk clusters</h2>
        </div>
        <Radar size={18} className="text-[hsl(var(--muted-foreground)/.65)]" />
      </div>
      <p className="mt-3 text-[11px] leading-[1.55] text-[hsl(var(--muted-foreground))]">
        Domains with the highest concentration of deceptive language in your recent scans.
      </p>
      <div className="mt-5 space-y-2">
        {domains.map((domain, index) => (
          <div key={domain} data-testid={`row-watched-domain-${index}`} className="flex items-center gap-2 rounded-xl bg-[hsl(var(--background)/.72)] px-3 py-2.5">
            <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-[hsl(var(--primary)/.15)] text-[#62821c]"><Globe2 size={12} /></span>
            <span className="min-w-0 flex-1 truncate font-mono text-[10px]">{domain}</span>
            <span className="font-mono text-[9px] text-[#a67c19]">{index === 0 ? '83' : index === 1 ? '71' : 'new'} risk</span>
          </div>
        ))}
      </div>
      <form onSubmit={addDomain} className="mt-4 flex gap-2">
        <input
          value={draft}
          onChange={(event) => {
            setDraft(event.target.value);
            setMessage('');
          }}
          data-testid="input-domain-watch"
          aria-label="Domain to watch"
          placeholder="Add a domain"
          className="focus-ring min-w-0 flex-1 rounded-xl border border-[hsl(var(--input))] bg-[hsl(var(--background)/.5)] px-3 py-2 text-[11px] placeholder:text-[hsl(var(--muted-foreground)/.65)] focus:border-[hsl(var(--primary))] focus:outline-none"
        />
        <button type="submit" data-testid="button-add-domain" className="focus-ring rounded-xl bg-[hsl(var(--primary))] px-3.5 text-[11px] font-bold text-[hsl(var(--primary-foreground))] hover:brightness-95">
          Add
        </button>
      </form>
      {message && <p data-testid="status-domain-watch" className="mt-2 font-mono text-[9px] text-[hsl(var(--muted-foreground))]">{message}</p>}
    </section>
  );
}

function Home() {
  const health = useHealthCheck();
  const analyze = useAnalyzeContent();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [draft, setDraft] = useState('');
  const [results, setResults] = useState<FlaggedItem[]>([]);
  const [analysisError, setAnalysisError] = useState('');
  const [scans, setScans] = useState(initialScans);
  const [showAllScans, setShowAllScans] = useState(false);
  const analyzerRef = useRef<HTMLElement>(null);

  const flaggedTotal = results.length || scans.reduce((sum, scan) => sum + scan.flags, 0);
  const averageScore = results.length
    ? Math.round(results.reduce((sum, item) => sum + item.threatScore, 0) / results.length)
    : 51;
  const healthLabel = health.isLoading ? 'Checking systems' : health.isError ? 'Connection issue' : 'Systems clear';
  const healthDetail = health.isLoading ? 'Contacting analyzer' : health.isError ? 'Retry to reconnect' : (health.data?.status ?? 'API online');

  const handleAnalyze = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const items = draft
      .split(/\n+/)
      .map((item) => item.trim())
      .filter(Boolean);
    if (!items.length) {
      setAnalysisError('Add at least one line of page copy to analyze.');
      return;
    }
    setAnalysisError('');
    analyze.mutate(
      { data: { items } },
      {
        onSuccess: (data) => {
          setResults(data);
          const score = data.length ? Math.round(data.reduce((sum, item) => sum + item.threatScore, 0) / data.length) : 0;
          setScans((current) => [
            {
              id: `scan-${Date.now()}`,
              label: items[0].slice(0, 35) + (items[0].length > 35 ? '…' : ''),
              detail: 'current browser session',
              flags: data.length,
              score,
              time: 'Just now',
              content: items.join('\n'),
            },
            ...current,
          ]);
        },
        onError: () => setAnalysisError('The analyzer could not be reached. Check the API status and try again.'),
      },
    );
  };

  const focusAnalyzer = () => {
    analyzerRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    window.setTimeout(() => document.getElementById('content-to-analyze')?.focus(), 350);
  };

  return (
    <div className="min-h-[100dvh] bg-[hsl(var(--background))]">
      <div className="noise-overlay" />
      <Sidebar mobileOpen={mobileOpen} onClose={() => setMobileOpen(false)} />
      <main className="min-h-[100dvh] lg:pl-[258px]">
        <header className="sticky top-0 z-20 flex h-[74px] items-center justify-between border-b border-[hsl(var(--border)/.75)] bg-[hsl(var(--background)/.9)] px-5 backdrop-blur-md sm:px-8 lg:px-10">
          <div className="flex items-center gap-3">
            <button
              type="button"
              data-testid="button-open-sidebar"
              aria-label="Open navigation"
              onClick={() => setMobileOpen(true)}
              className="focus-ring rounded-lg p-2 text-[hsl(var(--foreground))] hover:bg-[hsl(var(--muted))] lg:hidden"
            >
              <Menu size={19} />
            </button>
            <div className="hidden items-center gap-2 font-mono text-[9px] uppercase tracking-[0.16em] text-[hsl(var(--muted-foreground))] sm:flex">
              <span>TrustGuard</span><ChevronRight size={11} /><span className="text-[hsl(var(--foreground))]">Command center</span>
            </div>
            <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-[hsl(var(--foreground))] sm:hidden">Command center</span>
          </div>
          <div className="flex items-center gap-2.5">
            <label className="hidden items-center gap-2 rounded-xl border border-[hsl(var(--input))] bg-[hsl(var(--card)/.72)] px-3 py-2 md:flex">
              <Search size={14} className="text-[hsl(var(--muted-foreground))]" />
              <input data-testid="input-search" aria-label="Search scan log" placeholder="Search your trail" className="w-[145px] bg-transparent text-[10px] outline-none placeholder:text-[hsl(var(--muted-foreground)/.7)]" />
              <span className="font-mono text-[9px] text-[hsl(var(--muted-foreground)/.65)]">⌘ K</span>
            </label>
            <div className="relative">
              <button
                type="button"
                data-testid="button-notifications"
                aria-label="View notifications"
                onClick={() => setNotificationsOpen((open) => !open)}
                className="focus-ring relative rounded-xl border border-[hsl(var(--input))] bg-[hsl(var(--card)/.72)] p-2.5 text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))]"
              >
                <Bell size={15} />
                <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-[hsl(var(--accent))]" />
              </button>
              {notificationsOpen && (
                <div data-testid="panel-notifications" className="absolute right-0 top-12 w-[250px] rounded-2xl border border-[hsl(var(--card-border))] bg-[hsl(var(--card))] p-4 shadow-[var(--shadow-md)]">
                  <p className="font-mono text-[9px] uppercase tracking-[0.15em] text-[hsl(var(--muted-foreground))]">Signal inbox</p>
                  <p className="mt-2 text-[11px] font-semibold">Your scan trail is up to date.</p>
                  <p className="mt-1 text-[10px] leading-[1.5] text-[hsl(var(--muted-foreground))]">New domain-watch events will appear here.</p>
                </div>
              )}
            </div>
            <button
              type="button"
              data-testid="button-live-scan"
              onClick={focusAnalyzer}
              className="focus-ring hidden items-center gap-2 rounded-xl bg-[hsl(var(--secondary))] px-3.5 py-2.5 text-[10px] font-bold text-[hsl(var(--secondary-foreground))] hover:-translate-y-0.5 sm:flex"
            >
              <ScanLine size={14} />
              Live scan
            </button>
          </div>
        </header>

        <div className="mx-auto max-w-[1440px] px-5 pb-14 pt-8 sm:px-8 sm:pt-10 lg:px-10">
          <section className="reveal-up flex flex-col justify-between gap-7 lg:flex-row lg:items-end">
            <div className="max-w-[670px]">
              <div className="mb-4 flex items-center gap-2">
                <span className="status-dot h-2 w-2 rounded-full bg-[hsl(var(--primary))]" />
                <span data-testid="status-health" className="font-mono text-[9px] uppercase tracking-[0.17em] text-[hsl(var(--muted-foreground))]">
                  {healthLabel} <span className="text-[hsl(var(--muted-foreground)/.55)]">/ {healthDetail}</span>
                </span>
                {health.isError && (
                  <button
                    type="button"
                    data-testid="button-retry-health"
                    onClick={() => health.refetch()}
                    className="focus-ring flex items-center gap-1 rounded-md px-1.5 py-1 font-mono text-[9px] uppercase tracking-[0.08em] text-[hsl(var(--destructive))] hover:bg-[hsl(var(--destructive)/.08)]"
                  >
                    <RefreshCw size={11} /> Retry
                  </button>
                )}
              </div>
              <h1 className="max-w-[680px] text-[clamp(36px,5.2vw,70px)] font-extrabold leading-[.98] tracking-[-0.085em]">
                Read the web <span className="text-[#62821c]">before</span> it reads you.
              </h1>
              <p className="mt-5 max-w-[525px] text-[13px] leading-[1.7] text-[hsl(var(--muted-foreground))]">
                TrustGuard turns persuasive copy into a clear readout — so pressure looks like pressure, and your next click is actually yours.
              </p>
            </div>
            <div className="flex shrink-0 items-center gap-3 lg:pb-1">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] text-[hsl(var(--muted-foreground))]">
                <ShieldAlert size={19} />
              </div>
              <div>
                <p className="font-mono text-[9px] uppercase tracking-[0.16em] text-[hsl(var(--muted-foreground))]">Protection mode</p>
                <p className="mt-1 text-[12px] font-bold">Quietly watching</p>
              </div>
            </div>
          </section>

          <section className="mt-9 grid grid-cols-2 gap-3 lg:grid-cols-4 lg:gap-4">
            <Metric label="Signals found" value={flaggedTotal.toString().padStart(2, '0')} detail="Across your current trail" icon={Activity} accent="coral" />
            <Metric label="Average risk" value={`${averageScore}`} detail="Out of 100 threat points" icon={BarChart3} accent="teal" />
            <Metric label="Pages scanned" value={scans.length.toString().padStart(2, '0')} detail="In this browser session" icon={ScanLine} />
            <Metric label="Domains watched" value="02" detail="No new events today" icon={Globe2} accent="teal" />
          </section>

          <div className="mt-6 grid gap-6 lg:grid-cols-[minmax(0,1.35fr)_minmax(310px,.65fr)]">
            <Analyzer
              analyzerRef={analyzerRef}
              draft={draft}
              setDraft={setDraft}
              results={results}
              isPending={analyze.isPending}
              error={analysisError}
              onAnalyze={handleAnalyze}
              onExample={() => {
                setDraft(sampleCopy);
                setAnalysisError('');
                window.setTimeout(() => document.getElementById('content-to-analyze')?.focus(), 0);
              }}
            />
            <PatternDistribution results={results} />
          </div>

          <div className="mt-6 grid gap-6 lg:grid-cols-[minmax(0,1.35fr)_minmax(310px,.65fr)]">
            <RecentScans
              scans={scans}
              onReopen={(content) => {
                setDraft(content);
                setAnalysisError('');
                focusAnalyzer();
              }}
              showAll={showAllScans}
              onToggleShowAll={() => setShowAllScans((value) => !value)}
            />
            <DomainWatch />
          </div>

          <footer className="mt-10 flex flex-col justify-between gap-3 border-t border-[hsl(var(--border))] pt-5 text-[10px] text-[hsl(var(--muted-foreground))] sm:flex-row sm:items-center">
            <div className="flex items-center gap-2"><ShieldCheck size={13} className="text-[#62821c]" /> A calmer relationship with the internet.</div>
            <div className="flex items-center gap-4 font-mono text-[9px] uppercase tracking-[0.1em]"><span>Private session</span><span>Signal model v0.8</span></div>
          </footer>
        </div>
      </main>
    </div>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;