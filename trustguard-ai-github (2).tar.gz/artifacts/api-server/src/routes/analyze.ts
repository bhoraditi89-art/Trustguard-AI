import { Router, type IRouter } from "express";
import { analyzeItems } from "../lib/trustguard";

const router: IRouter = Router();

router.post("/analyze", (req, res) => {
  try {
    res.json(analyzeItems(req.body));
  } catch (error) {
    req.log.warn({ err: error }, "Invalid analysis request");
    res.status(400).json({ error: "Expected an object with an items array of text strings." });
  }
});

export default router;